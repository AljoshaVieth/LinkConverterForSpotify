package de.aljoshavieth.spotifytoapple;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView idText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        handleIntent();
    }

    @Override
    protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent();
    }

    private void handleIntent() {
        // ATTENTION: This was auto-generated to handle app links.
        Intent appLinkIntent = getIntent();
        String appLinkAction = appLinkIntent.getAction();
        Uri appLinkData = appLinkIntent.getData();
        idText = findViewById(R.id.idText);
        if (appLinkData != null) {
            String trackID = appLinkData.toString();
            getTrackInfo(trackID);
        }
    }

    public void getTrackInfo(String spotifyUrl) {
        idText.setText(spotifyUrl);
        new JsonTask().execute("https://api.song.link/v1-alpha.1/links?url=" + spotifyUrl + "&userCountry=DE");
        Log.d("----SPOTIFYTOAPPLEMUSIC", "started async task");

    }

    private class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();
            Log.d("----SPOTIFYTOAPPLEMUSIC", "pre execute");
        }

        protected String doInBackground(String... params) {
            Log.d("----SPOTIFYTOAPPLEMUSIC", "do in background");

            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("-------Response: ", "> " + line);   //here u ll get whole response...... :-)

                }

                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            String response = "error";
            System.out.println("----------------Result:");
            System.out.println(result);
            try {
                JSONObject jsonObject = new JSONObject(result);
                response = jsonObject.getString("pageUrl");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            super.onPostExecute(result);
            System.out.println("---<-y-y--yy------------ Response: " + response);
            idText.setText(response);
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(response));
            startActivity(browserIntent);
            MainActivity.this.finish();
            System.exit(0);
        }
    }
}
